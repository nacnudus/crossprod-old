function Y = round2up(X)
% Round towards the nearest integer (asymmetric rounding / round half up)
%
% (c) 2013 Stephen Cobeldick
%
% Rounds the elements of X to the nearest integers. X may be an N-D matrix.
% Elements with a fraction of 0.5 round up to the next integer (towards +Inf).
% For complex X, the imaginary and real parts are rounded independently.
%
% Syntax:
%  Y = round2up(X)
%
% See also ROUND2DN ROUND2EV ROUND2OD ROUND2RA ROUND2ZE ROUND2SF ROUND2DP ROUND60063 DATEROUND ROUND NEAREST
%
% Note 1: Known as asymmetric rounding or round half towards plus infinity.
% Note 2: MATLAB's Fixed-Point toolbox provides "nearest".

if isreal(X)
    Z = rem(X,1);
    Z(Z~=-0.5) = 0;
else
    R = rem(real(X),1);
    J = rem(imag(X),1);
    R(R~=-0.5) = 0;
    J(J~=-0.5) = 0;
    Z = complex(R,J);
end
Y = round(X-Z);
%----------------------------------------------------------------------End!