function Y = round2od(X)
% Round towards the nearest integer (unbiased rounding / round half to odd)
%
% (c) 2013 Stephen Cobeldick
%
% Rounds the elements of X to the nearest integers. X may be an N-D matrix.
% Elements with a fraction of 0.5 round to the nearest odd integer.
% For complex X, the imaginary and real parts are rounded independently.
%
% Syntax:
%  Y = round2od(X)
%
% See also ROUND2EV ROUND2DN ROUND2UP ROUND2RA ROUND2ZE ROUND2SF ROUND2DP ROUND60063 DATEROUND ROUND

if isreal(X)
    Z = rem(X,2);
    Z(abs(Z)~=1.5) = 0;
else
    R = rem(real(X),2);
    J = rem(imag(X),2);
    R(abs(R)~=1.5) = 0;
    J(abs(J)~=1.5) = 0;
    Z = complex(R,J);
end
Y = round(X-Z/3);
%----------------------------------------------------------------------End!