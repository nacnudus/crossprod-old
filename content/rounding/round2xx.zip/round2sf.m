function Y = round2sf(X,SgF,FnH)
% Round a numeric to given significant figures. Choose any rounding function.
%
% (c) 2013 Stephen Cobeldick
%
% Round to given significant figures. X may be an N-D matrix. The
% default rounding method is MATLAB's "round" function: an alternative
% rounding method may be selected by providing a function handle.
% The significant figures may be defined by a numeric scalar or matrix.
% For complex X, the imaginary and real parts are rounded independently.
%
% Syntax:
%  Y = round2sf(X)            % Round to one sig-fig, use MATLAB's "round".
%  Y = round2sf(X,SgF)        % Select sig-figs, use MATLAB's "round".
%  Y = round2sf(X,SgF,FnH)    % Select sig-figs, use any rounding function.
%
% See also ROUND2DN ROUND2UP ROUND2EV ROUND2OD ROUND2RA ROUND2ZE ROUND2DP ROUND60063 DATEROUND CEIL FLOOR FIX ROUND
%
% ### Rounding Functions ###
%
% Function |Description:                       |Example Values:
% Name:    |Round decimal digits...            |-3.5|-2.5|-1.5|-0.5|0.5|1.5|2.5|3.5
% ---------|-----------------------------------|----|----|----|----|---|---|---|---
% floor    |all down (towards minus infinity)  |-4  |-3  |-2  |-1  |0  |1  |2  |3
% ceil     |all up (towards plus infinity)     |-3  |-2  |-1  | 0  |1  |2  |3  |4
% fix      |all towards zero                   |-3  |-2  |-1  | 0  |0  |1  |2  |3
% round *  |half away from zero                |-4  |-3  |-2  |-1  |1  |2  |3  |4 *
% ---------|-----------------------------------|----|----|----|----|---|---|---|---
% round2ze |half towards zero                  |-3  |-2  |-1  | 0  |0  |1  |2  |3
% round2dn |half down (towards minus infinity) |-4  |-3  |-2  |-1  |0  |1  |2  |3
% round2up |half up (towards plus infinity)    |-3  |-2  |-1  | 0  |1  |2  |3  |4
% round2ev |half towards nearest even integer  |-4  |-2  |-2  | 0  |0  |2  |2  |4
% round2od |half towards nearest odd integer   |-3  |-3  |-1  |-1  |1  |1  |3  |3
% round2ra |half randomly (stochastic rounding)|-4  |-2  |-1  | 0  |0  |2  |3  |3 !
% ---------|-----------------------------------|----|----|----|----|---|---|---|---
%
% ### Examples ###
%
% round2sf([1111,222.2,33.33,4.444,0.5555])
%  ans = [1000,200,30,4,0.6]
%
% round2sf([1111,222.2,33.33,4.444,0.5555],1)
%  ans = [1000,200,30,4,0.6]
%
% round2sf([1111,222.2,33.33,4.444,0.5555],2)
%  ans = [1100,220,33,4.4,0.56]
%
% round2sf([1111,222.2,33.33,4.444,0.5555],3)
%  ans = [1110,222,33.3,4.44,0.556]
%
% round2sf([1111,222.2,33.33,4.444,0.5555],3,@ceil)
%  ans = [1120,223,33.4,4.45,0.556]
%
% round2sf([6.6666,6.6666;6.6666,6.6666],[1,2;3,4])
%  ans = [7,6.7;6.67,6.667]
%
% ### Input & Output Arguments ###
%
% Inputs (default=*):
%  X   = Numeric array of any size, with elements to be rounded.
%  SgF = Numeric scalar, significant figures, 0<N<Inf, 1*.
%      = Numeric array, same size as X, sig-figs for each element of X.
%  FnH = Function handle of any rounding function, eg: @fix, @round*.
%
% Output:
%  Y   = Numeric array, same size as X, with rounded elements of X.
%
% Inputs = (X,SgF*,FnH*)
% Output = Y

if nargin<3
    % Default rounding function:
    FnH = @round;
else
    % Check user supplied rounding function:
    assert(isa(FnH,'function_handle'),'Third argument <FnH> must be a function handle.')
    T = FnH([-1000.9,-100.2,-10.7,-1.4,0.5,1.6,10.3,100.8,1000.1]);
    assert(isnumeric(T)&&all(rem(T,1)==0),'Function <FnH> must return a rounded numeric.')
end
%
if nargin<2
    % Default number of significant figures:
    SgF = 1;
else
    assert(all(isfinite(SgF(:)))&&isreal(SgF),'Second argument <SgF> must be real numeric.')
end
%
if isreal(X)% Real
    % Adjustment for significant figures:
    PwX = 1-SgF+floor(log10(abs(X)));
    PwX(~isfinite(PwX)) = 0;
    % Adjust, Round, Unadjust:
    Y = FnH(X.*10.^-PwX).*10.^PwX;
else% Complex
    R = real(X);
    J = imag(X);
    % Adjustment for significant figures:
    PwR = 1-SgF+floor(log10(abs(R)));
    PwJ = 1-SgF+floor(log10(abs(J)));
    PwR(~isfinite(PwR)) = 0;
    PwJ(~isfinite(PwJ)) = 0;
    % Adjust, Round, Unadjust:
    Y = complex(FnH(R.*10.^-PwR).*10.^PwR,FnH(J.*10.^-PwJ).*10.^PwJ);
end
%----------------------------------------------------------------------End!